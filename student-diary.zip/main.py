import os
import getpass

USER_FILE = "users.txt"
BOOKS_FILE = "books.txt"

# Ensure the necessary files exist
open(USER_FILE, "a").close()
open(BOOKS_FILE, "a").close()


def register_user():
    print("=== Register ===")
    username = input("Enter a new username: ")
    if not username:
        print("Error: Username cannot be empty.")
        return

    password = getpass.getpass("Enter a new password: ")
    if not password:
        print("Error: Password cannot be empty.")
        return

    with open(USER_FILE, "r") as f:
        for line in f:
            if line.startswith(username + ":"):
                print("Error: Username already exists.")
                return

    with open(USER_FILE, "a") as f:
        f.write(f"{username}:{password}\n")
    print("Registration successful!")


def login_user():
    print("=== Login ===")
    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")

    with open(USER_FILE, "r") as f:
        for line in f:
            stored_username, stored_password = line.strip().split(":")
            if username == stored_username and password == stored_password:
                print("Login successful!")
                logged_in_menu(username)
                return
    print("Error: Invalid username or password.")


def logged_in_menu(username):
    while True:
        print("=== Student's Diary ===")
        print("1. Add books for today's timetable")
        print("2. View books added")
        print("3. Logout")
        choice = input("Choose an option: ")

        if choice == "1":
            add_books(username)
        elif choice == "2":
            view_books(username)
        elif choice == "3":
            print("Logging out...")
            break
        else:
            print("Invalid option. Please try again.")


def add_books(username):
    timetable = input("Enter today's timetable (e.g., Math, Science): ")
    if not timetable:
        print("Error: Timetable cannot be empty.")
        return

    with open(BOOKS_FILE, "a") as f:
        f.write(f"{username}:{timetable}\n")
    print("Books added successfully for today's timetable!")


def view_books(username):
    user_books = []
    with open(BOOKS_FILE, "r") as f:
        for line in f:
            if line.startswith(username + ":"):
                user_books.append(line.strip().split(":")[1])

    if not user_books:
        print(f"No books found for {username}.")
    else:
        print(f"Books for {username}:")
        for book in user_books:
            print(book)


# Main menu
while True:
    print("=== Welcome to Student's Diary ===")
    print("1. Register")
    print("2. Login")
    print("3. Exit")
    action = input("Choose an option: ")

    if action == "1":
        register_user()
    elif action == "2":
        login_user()
    elif action == "3":
        print("Exiting the program. Goodbye!")
        break
    else:
        print("Invalid option. Please try again.")
