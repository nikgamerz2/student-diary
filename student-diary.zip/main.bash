#!/bin/bash

# File paths for storing user data
USER_FILE="users.txt"
BOOKS_FILE="books.txt"

# Ensure the necessary files exist
touch "$USER_FILE" "$BOOKS_FILE"

# Function to register a new user
register_user() {
  echo "=== Register ==="
  read -p "Enter a new username: " username
  if [ -z "$username" ]; then
    echo "Error: Username cannot be empty."
    return
  fi

  read -sp "Enter a new password: " password
  echo
  if [ -z "$password" ]; then
    echo "Error: Password cannot be empty."
    return
  fi

  if grep -q "^$username:" "$USER_FILE"; then
    echo "Error: Username already exists."
  else
    echo "$username:$password" >>"$USER_FILE"
    echo "Registration successful!"
  fi
}

# Function to log in a user
login_user() {
  echo "=== Login ==="
  read -p "Enter your username: " username
  read -sp "Enter your password: " password
  echo

  if grep -q "^$username:$password$" "$USER_FILE"; then
    echo "Login successful!"
    logged_in_menu "$username"
  else
    echo "Error: Invalid username or password."
  fi
}

# Function for the logged-in menu
logged_in_menu() {
  local username="$1"

  while true; do
    echo "=== Student's Diary ==="
    echo "1. Add books for today's timetable"
    echo "2. View books added"
    echo "3. Logout"
    read -p "Choose an option: " choice

    case "$choice" in
    1)
      add_books "$username"
      ;;
    2)
      view_books "$username"
      ;;
    3)
      echo "Logging out..."
      break
      ;;
    *)
      echo "Invalid option. Please try again."
      ;;
    esac
  done
}

# Function to add books
add_books() {
  local username="$1"
  read -p "Enter today's timetable (e.g., Math, Science): " timetable
  if [ -z "$timetable" ]; then
    echo "Error: Timetable cannot be empty."
    return
  fi

  echo "$username:$timetable" >>"$BOOKS_FILE"
  echo "Books added successfully for today's timetable!"
}

# Function to view books
view_books() {
  local username="$1"
  local user_books
  user_books=$(grep "^$username:" "$BOOKS_FILE" | cut -d':' -f2)

  if [ -z "$user_books" ]; then
    echo "No books found for $username."
  else
    echo "Books for $username:"
    echo "$user_books"
  fi
}

# Main menu
while true; do
  echo "=== Welcome to Student's Diary ==="
  echo "1. Register"
  echo "2. Login"
  echo "3. Exit"
  read -p "Choose an option: " action

  case "$action" in
  1)
    register_user
    ;;
  2)
    login_user
    ;;
  3)
    echo "Exiting the program. Goodbye!"
    exit 0
    ;;
  *)
    echo "Invalid option. Please try again."
    ;;
  esac
done